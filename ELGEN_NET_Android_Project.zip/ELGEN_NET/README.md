# ELGEN NET — Android starter project

- Package: `com.elgen.net`
- Minimum Android: 10 (API 29)
- Theme: dark / neon green
- Current MVP: local connection type, local IPv4 address, default gateway, and router security tips.
- This starter does not crack Wi-Fi, collect passwords, or scan networks belonging to others.

## Build
Open this folder in Android Studio (recent version), allow Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The APK is usually created under `app/build/outputs/apk/debug/`.

Note: This project source is provided; an APK has not been built or tested in this environment.
