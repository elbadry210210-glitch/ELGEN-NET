package com.elgen.net

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.net.Inet4Address

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 21, 31)
    private val panel = Color.rgb(28, 41, 57)
    private val green = Color.rgb(53, 214, 160)
    private val muted = Color.rgb(170, 183, 200)
    private lateinit var content: LinearLayout
    private lateinit var networkInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshNetworkInfo()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("🛡  ELGEN NET", 27f, green, true)
        addText("فحص الشبكة وأمان الاتصال", 15f, muted, false, 8)
        addPanel {
            addText("حالة الاتصال", 14f, muted, false)
            addText("معلومات الشبكة", 21f, Color.WHITE, true, 5)
            networkInfo = addText("جارٍ قراءة بيانات الشبكة…", 14f, Color.WHITE, false, 4)
            addButton("تحديث المعلومات") { refreshNetworkInfo() }
        }
        addPanel {
            addText("الأجهزة والخدمات المحلية", 19f, Color.WHITE, true)
            addText(
                "يمكن للتطبيق اكتشاف بعض الخدمات التي تعلن عن نفسها على شبكتك المحلية. " +
                "قد لا تظهر كل الأجهزة المتصلة.",
                14f, muted, false, 8
            )
            addText("ميزة اكتشاف الخدمات ستُضاف في التحديث التالي.", 14f, green, true)
        }
        addPanel {
            addText("نصائح حماية الراوتر", 19f, Color.WHITE, true)
            listOf(
                "استخدم WPA2-AES أو WPA3 إن كان متاحًا.",
                "اجعل كلمة مرور Wi‑Fi قوية وفريدة.",
                "غيّر كلمة مرور لوحة إدارة الراوتر الافتراضية.",
                "حدّث برنامج الراوتر من الشركة المصنّعة.",
                "عطّل WPS إذا لم تكن بحاجة إليه."
            ).forEach { addText("•  $it", 14f, Color.WHITE, false, 7) }
        }
        addText("ELGEN NET  •  الإصدار 1.0", 12f, muted, false, 18)
    }

    private fun addPanel(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            background = rounded(panel, 18)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 16 }
        content.addView(box, lp)
        box.block()
    }

    private fun addText(
        value: String, size: Float, color: Int, bold: Boolean,
        top: Int = 0
    ): TextView {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(0, top, 0, 5)
        }
        content.addView(t)
        return t
    }

    private fun LinearLayout.addText(
        value: String, size: Float, color: Int, bold: Boolean,
        bottom: Int = 0
    ): TextView {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(0, 0, 0, bottom)
        }
        addView(t)
        return t
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(bg)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 }
        content.addView(b, lp)
    }

    private fun LinearLayout.addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(bg)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }
        addView(b, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshNetworkInfo() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        if (network == null) {
            networkInfo.text = "لا يوجد اتصال نشط بالإنترنت أو الشبكة."
            return
        }
        val caps = cm.getNetworkCapabilities(network)
        val kind = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "بيانات الهاتف"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "اتصال آخر"
        }
        val lp: LinkProperties? = cm.getLinkProperties(network)
        val ipv4 = lp?.linkAddresses
            ?.map { it.address }
            ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress ?: "غير متاح"
        val gateway = lp?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress ?: "غير متاح"

        networkInfo.text = "نوع الاتصال: $kind\nعنوان IP المحلي: $ipv4\nالبوابة الافتراضية: $gateway"
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
}
